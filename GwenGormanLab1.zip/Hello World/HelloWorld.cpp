//HelloWorld.cpp -- This program prints hello world to the screen

//CSIS 111-B02

//Public Domain





//Include statements

#include <iostream>
#include <string>



using namespace std;



//Global declarations: Constants and type definitions only -- no variables



//Function prototypes



int main()

{

	//In cout statement below substitute your name and lab number

	cout << "Gwen Gorman -- Lab 1" << endl << endl;

	//Variable declarations

	//Program logic

	cout << "Hello World!" << endl << endl;

	//Closing program statements

	system("pause");

	return 0;

}



//Function definitions

